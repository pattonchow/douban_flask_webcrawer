# -*- codeing = utf-8 -*-
# @Time :2021/8/13 20:04
# @Author: PATTON
# @File : testCloud.py
# @Software: PyCharm

import jieba
from matplotlib import pyplot as plt
from wordcloud import WordCloud